# PWA Smart Redirect - big incontri

Questo pacchetto contiene una Progressive Web App (PWA) di reindirizzamento creata automaticamente con **PWA Builder**.

## Struttura dei File
- `index.html`: File principale con la logica temporizzata ed il benvenuto grafico.
- `manifest.json`: Fornisce i metadati per l'installazione su smartphone.
- `sw.js`: Gestore della cache offline (Service Worker) per l'avvio autonomo.
- `cover.jpg`: Immagine di sfondo ad alta definizione per la copertina di prima visita.
- `icon-192.png` e `icon-512.png`: Icone dell'applicazione per la Homescreen del telefono.

## Istruzioni per la pubblicazione su GitHub Pages (100% Gratis)
1. Estrai il contenuto di questo archivio ZIP sul tuo computer.
2. Crea un nuovo repository pubblico sul tuo account GitHub (es. `big incontri`).
3. Carica tutti i file estratti all'interno del repository.
4. Vai su **Settings** (Impostazioni) del repository -> **Pages**.
5. Sotto la voce **Build and deployment**, imposta la sorgente su **Deploy from a branch** e seleziona il branch `main` (cartella `/ (root)`).
6. Clicca su **Save**. Dopo un minuto il tuo sito sarà online con protocollo sicuro HTTPS all'indirizzo `https://<tuo-username>.github.io/big incontri/`.

## Installazione sul Telefono
- **Android (Chrome)**: Apri il link del sito e comparirà automaticamente il banner "Aggiungi a schermata Home" oppure clicca sui tre pallini in alto a destra e seleziona **Installa applicazione**.
- **iOS (Safari)**: Apri il link su Safari, premi il pulsante di condivisione (icona quadrata con freccia verso l'alto) e seleziona **Aggiungi alla schermata Home**.
